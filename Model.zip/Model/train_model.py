import os
import sys
import numpy as np
import rasterio
import tensorflow as tf


base_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(base_dir)
sys.path.append(base_dir)

from toa_helper import enhanced_dn_to_toa, simple_dn_to_toa
from tensorflow.keras import layers, models
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report


real_data_dir = os.path.join(project_root, 'RealSatelliteData')
weights_path = os.path.join(base_dir, 'model_weights.weights.h5')

lmax = [52.0, 47.0, 31.5]  
lmin = [0.0, 0.0, 0.0]


CLASS_WEIGHTS = tf.constant([1.5, 1.0, 2.0], dtype=tf.float32)

def weighted_categorical_crossentropy(y_true, y_pred):
    """Strong shadow-focused weighted categorical crossentropy."""
    
    y_pred = tf.clip_by_value(y_pred, 1e-7, 1.0)
    
   
    weights = tf.reduce_sum(CLASS_WEIGHTS * y_true, axis=-1)
    
    
    cce = tf.keras.losses.categorical_crossentropy(y_true, y_pred)
    
    
    weighted_loss = cce * weights
    return tf.reduce_mean(weighted_loss)


print("Loading and preprocessing REAL satellite data...")
X_list, Y_list = [], []

scene_dirs = []
for item in os.listdir(real_data_dir):
    item_path = os.path.join(real_data_dir, item)
    if os.path.isdir(item_path) and item != 'TOA_help':
        scene_dirs.append(item_path)
scene_dirs = sorted(scene_dirs)
print(f"Found {len(scene_dirs)} scene directories")

processed_scenes = 0
for scene_dir in scene_dirs:
    try:
        scene_name = os.path.basename(scene_dir)
        print(f"Processing scene: {scene_name}")
        band_files = [os.path.join(scene_dir, f'BAND{i}.tif') for i in [2, 3, 4]]
        if not all(os.path.exists(bf) for bf in band_files):
            print(f"Missing band files in {scene_name}, skipping.")
            continue
        bands = [rasterio.open(bf).read(1) for bf in band_files]
        img = np.stack(bands, axis=-1)
        toa_img = np.zeros_like(img, dtype=np.float32)
        for i in range(3):
            toa_img[:, :, i] = enhanced_dn_to_toa(img[:, :, i], scene_dir, i+2)
        
        
        cloud_mask = (toa_img[:, :, 2] > 0.25).astype(np.uint8)
        shadow_mask = ((toa_img[:, :, 0] < 0.05) & (toa_img[:, :, 1] < 0.05)).astype(np.uint8)
        
        
        segmentation_mask = np.zeros_like(cloud_mask, dtype=np.uint8)
        
        
        cloud_threshold = 0.35  
        shadow_threshold = 0.03  
        
        
        cloud_mask_adj = (toa_img[:, :, 2] > cloud_threshold).astype(np.uint8)
        shadow_mask_adj = ((toa_img[:, :, 0] < shadow_threshold) & (toa_img[:, :, 1] < shadow_threshold)).astype(np.uint8)
        
        
        segmentation_mask[shadow_mask_adj == 1] = 2
        segmentation_mask[(cloud_mask_adj == 1) & (shadow_mask_adj == 0)] = 1 
       
        
        
        if np.sum(segmentation_mask == 0) == 0:
           
            low_intensity = (toa_img[:, :, 0] < 0.1) & (toa_img[:, :, 1] < 0.1) & (toa_img[:, :, 2] < 0.1)
            segmentation_mask[low_intensity] = 0  
        
        toa_img_resized = tf.image.resize(toa_img, [256, 256]).numpy()
        segmentation_mask_resized = tf.image.resize(np.expand_dims(segmentation_mask, -1), [256, 256]).numpy().squeeze().astype(np.uint8)
        
        
        segmentation_onehot = tf.keras.utils.to_categorical(segmentation_mask_resized, num_classes=3)
        
        X_list.append(toa_img_resized)
        Y_list.append(segmentation_onehot)
        processed_scenes += 1
        print(f"Successfully processed {scene_name}")
    except Exception as e:
        print(f"Skipping scene {os.path.basename(scene_dir)} due to error: {e}")
        continue
print(f"Successfully processed {processed_scenes} real satellite scenes")

if not X_list:
    print("No real data was loaded. Exiting training.")
    sys.exit(1)

X = np.stack(X_list)
Y = np.stack(Y_list)


val_index = 9  
train_indices = [i for i in range(len(X)) if i != val_index]


cloud_threshold = 0.30
shadow_threshold = 0.04

def to_multilabel(toa_img):
    cloud_mask = (toa_img[:, :, 2] > cloud_threshold).astype(np.uint8)
    shadow_mask = ((toa_img[:, :, 0] < shadow_threshold) & (toa_img[:, :, 1] < shadow_threshold)).astype(np.uint8)
    cloud_mask_resized = tf.image.resize(np.expand_dims(cloud_mask, -1), [256, 256]).numpy().squeeze().astype(np.uint8)
    shadow_mask_resized = tf.image.resize(np.expand_dims(shadow_mask, -1), [256, 256]).numpy().squeeze().astype(np.uint8)
    return np.stack([cloud_mask_resized, shadow_mask_resized], axis=-1)

X_train = X[train_indices]
Y_train = np.stack([to_multilabel(X[i]) for i in train_indices])
X_val = X[[val_index]]
Y_val = np.stack([to_multilabel(X[val_index])])


print("\nMulti-label Class Distribution (Training):")
cloud_pixels = np.sum(Y_train[:, :, :, 0])
shadow_pixels = np.sum(Y_train[:, :, :, 1])
background_pixels = np.sum((Y_train[:, :, :, 0] == 0) & (Y_train[:, :, :, 1] == 0))
total_pixels = np.prod(Y_train.shape[:3])
print(f"  Background: {background_pixels} ({background_pixels/total_pixels*100:.2f}%)")
print(f"  Cloud:      {cloud_pixels} ({cloud_pixels/total_pixels*100:.2f}%)")
print(f"  Shadow:     {shadow_pixels} ({shadow_pixels/total_pixels*100:.2f}%)")

print("\nMulti-label Class Distribution (Validation):")
cloud_pixels = np.sum(Y_val[:, :, :, 0])
shadow_pixels = np.sum(Y_val[:, :, :, 1])
background_pixels = np.sum((Y_val[:, :, :, 0] == 0) & (Y_val[:, :, :, 1] == 0))
total_pixels = np.prod(Y_val.shape[:3])
print(f"  Background: {background_pixels} ({background_pixels/total_pixels*100:.2f}%)")
print(f"  Cloud:      {cloud_pixels} ({cloud_pixels/total_pixels*100:.2f}%)")
print(f"  Shadow:     {shadow_pixels} ({shadow_pixels/total_pixels*100:.2f}%)")

print(f"\nValidation scene index is hardcoded to {val_index} for reproducibility. Retraining will always use this split.")


def build_unet(input_shape, n_classes=2):
    inputs = layers.Input(shape=input_shape)
    c1 = layers.Conv2D(16, 3, activation='relu', padding='same')(inputs)
    p1 = layers.MaxPooling2D()(c1)
    c2 = layers.Conv2D(32, 3, activation='relu', padding='same')(p1)
    p2 = layers.MaxPooling2D()(c2)
    b = layers.Conv2D(64, 3, activation='relu', padding='same')(p2)
    u2 = layers.UpSampling2D()(b)
    u2 = layers.concatenate([u2, c2])
    c3 = layers.Conv2D(32, 3, activation='relu', padding='same')(u2)
    u1 = layers.UpSampling2D()(c3)
    u1 = layers.concatenate([u1, c1])
    c4 = layers.Conv2D(16, 3, activation='relu', padding='same')(u1)
    outputs = layers.Conv2D(n_classes, 1, activation='sigmoid')(c4)
    return models.Model(inputs, outputs)

model = build_unet(input_shape=(256, 256, 3), n_classes=2)
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

print("\nTraining multi-label U-Net with binary crossentropy...")
history = model.fit(X_train, Y_train, validation_data=(X_val, Y_val), epochs=10, batch_size=2, verbose=1)


model.save_weights(weights_path)
print(f"\nModel weights saved to {weights_path}") 